//
//  AppTableCell.h
//  EvoFlight ObjC
//
//  Created by user on 7/15/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppTableCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *appImage;
@property (weak, nonatomic) IBOutlet UILabel *appName;
@property (weak, nonatomic) IBOutlet UILabel *appDescription;

@end
