//
//  SettingsTableVC.m
//  EvoFlight ObjC
//
//  Created by user on 7/15/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import "SettingsTableVC.h"

@interface SettingsTableVC ()

@end

@implementation SettingsTableVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // classifying NSUserDefaults
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    NSObject *object = [prefs objectForKey:@"udid"];
    // setting udid
    if(object == nil) {
        NSLog(@"UDID has not yet been fetched.");
    } else {
        NSString *savedValue = [[NSUserDefaults standardUserDefaults]
                                stringForKey:@"udid"];
        NSString *newUdid = [NSString stringWithFormat:@"%@", savedValue];
        newUdid = [newUdid stringByReplacingOccurrencesOfString:@"evoflight://?udid="
                                             withString:@""];
        _udid.text = [NSString stringWithFormat:@"%@", newUdid];
    }
    
    _deviceName.text = [[UIDevice currentDevice] name];
    NSString *deviceOSID = [[UIDevice currentDevice] systemVersion];
    NSString *deviceBuildID = [DeviceInfo getBuildID];
    _deviceOS.text = [NSString stringWithFormat:@"%@ (%@)", deviceOSID, deviceBuildID];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/bin/bash"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/sbin/sshd"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/etc/apt"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/private/var/lib/apt/"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Cydia.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/private/var/mobile/Library/SBSettings/Themes"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/MobileSubstrate.dylib"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/DynamicLibraries/Veency.plist"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Library/MobileSubstrate/DynamicLibraries/LiveClock.plist"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/LaunchDaemons/com.ikey.bbot.plist"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/System/Library/LaunchDaemons/com.saurik.Cydia.Startup.plist"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/cache/apt"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/lib/apt"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/lib/cydia"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/log/syslog"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/var/tmp/cydia.log"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/bin/sh"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/sbin/sshd"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/libexec/ssh-keysign"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/sbin/sshd"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/bin/sshd"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/usr/libexec/sftp-server"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/etc/ssh/sshd_config"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/RockApp.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Icy.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/WinterBoard.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/SBSettings.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/MxTube.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/IntelliScreen.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/FakeCarrier.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/blackra1n.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Anemone.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/BatteryLife.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/CertRemainTime.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Ext3nder.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Filza.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/iFile.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Flex.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/MTerminal.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/NewTerm.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/TSSSaver.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/iCleaner.app"]) {
        
        _jailbroken.textColor = [UIColor greenColor];
        _jailbroken.text = @"Yes";
        
    } else {
        
        _jailbroken.textColor = [UIColor redColor];
        _jailbroken.text = @"No";
        
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    if (indexPath.section == 1 && indexPath.row == 0) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://twitter.com/MasonD3V"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 2 && indexPath.row == 0) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://twitter.com/SentryRevoke"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 2 && indexPath.row == 1) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://hollr2099.net"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 2 && indexPath.row == 2) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://twitter.com/MaxRield"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 2 && indexPath.row == 3) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://icons8.com"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 3 && indexPath.row == 0) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://twitter.com/JustinAlexP"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 3 && indexPath.row == 1) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://twitter.com/AppleBetasDev"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 3 && indexPath.row == 2) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://twitter.com/nullriver"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 3 && indexPath.row == 3) {
        UIApplication *mySafari = [UIApplication sharedApplication];
        NSURL *myURL = [[NSURL alloc]initWithString:@"https://twitter.com/CreatureSurvive"];
        [mySafari openURL:myURL];
    } else if (indexPath.section == 0 && indexPath.row == 3) {
        
        if (![_udid.text  isEqual: @"Fetching Needed"]) {
            UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
            [pasteboard setString:_udid.text];
            NSString *copiedUDID = [NSString stringWithFormat:@"You have copied your UDID to your clipboard.\n\n%@", _udid.text];
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"EvoFlight" message:copiedUDID preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"Okay" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                // nothing ;)
            }];
            [alert addAction:defaultAction];
            [self presentViewController:alert animated:YES completion:nil];
        } else {
            UIApplication *mySafari = [UIApplication sharedApplication];
            NSURL *myURL = [[NSURL alloc]initWithString:@"https://jelteam.000webhostapp.com/EvoFlight"];
            [mySafari openURL:myURL];
        }
        
    }
}

@end
