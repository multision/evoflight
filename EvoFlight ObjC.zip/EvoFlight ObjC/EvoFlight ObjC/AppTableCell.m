//
//  AppTableCell.m
//  EvoFlight ObjC
//
//  Created by user on 7/15/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import "AppTableCell.h"

@implementation AppTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
