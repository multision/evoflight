//
//  ViewController.h
//  EvoFlight ObjC
//
//  Created by user on 7/14/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *gradientView;

@end

