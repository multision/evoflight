//
//  AppTableVC.m
//  EvoFlight ObjC
//
//  Created by user on 7/15/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import "AppTableVC.h"
#import "AppTableCell.h"
#import <AFNetworking/AFNetworking.h>

@interface AppTableVC ()

@end

@implementation AppTableVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    AppTableCell *cell = [tableView dequeueReusableCellWithIdentifier:@"reuseIdentifier" forIndexPath:indexPath];
    
    return cell;
}

@end
