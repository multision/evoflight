//
//  ViewController.m
//  EvoFlight ObjC
//
//  Created by user on 7/14/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *htmlFile = [[NSBundle mainBundle] pathForResource:@"gradient" ofType:@"html"];
    NSString* htmlString = [NSString stringWithContentsOfFile:htmlFile encoding:NSUTF8StringEncoding error:nil];
    [_gradientView loadHTMLString:htmlString baseURL: [[NSBundle mainBundle] bundleURL]];
    
}

- (IBAction)generalInfo:(id)sender {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"EvoFlight" message:@"We recommend changing the Bundle ID to your own using iFile/Filza. Doing so will allow multiple app installations.\n\nIf this is not done and you already have an app installed, each new app you install will overwrite the one that currently exists.\n\nPlease note AppSync Unified is required to install these applications." preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *defaultAction = [UIAlertAction actionWithTitle:@"I Understand" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        // nothing ;)
    }];
    [alert addAction:defaultAction];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
