//
//  AppDelegate.h
//  EvoFlight ObjC
//
//  Created by user on 7/14/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

