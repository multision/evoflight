//
//  SettingsTableVC.h
//  EvoFlight ObjC
//
//  Created by user on 7/15/18.
//  Copyright © 2018 MasonD3V. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DeviceInfo.h"

@interface SettingsTableVC : UITableViewController

@property (weak, nonatomic) IBOutlet UILabel *deviceName;
@property (weak, nonatomic) IBOutlet UILabel *deviceOS;
@property (weak, nonatomic) IBOutlet UILabel *udid;
@property (weak, nonatomic) IBOutlet UILabel *jailbroken;

@end
